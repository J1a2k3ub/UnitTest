﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

[TestClass]
public class HerniPostavaTests
{
    [TestMethod]
    public void HerniPostava_NastaveniJmena_Test()
    {
        HerniPostava postava = new HerniPostava("Legolas");
        Assert.AreEqual("Legolas", postava.Jmeno);
    }
    [TestMethod]
    public void HerniPostava_ZmenaPozice_FungujeSpravne()
    {
        HerniPostava postava = new HerniPostava("Test");
        postava.ZmenaPozice(5, 10);

        Assert.AreEqual(5, postava.PoziceX);
        Assert.AreEqual(10, postava.PoziceY);
    }

    [TestMethod]
    public void HerniPostava_PrilisDlouheJmeno_Test()
    {
        HerniPostava postava = new HerniPostava("PřílišDlouhéJméno");
        Assert.AreNotEqual("PřílišDlouhéJméno", postava.Jmeno);
    }
    [TestMethod]
    public void HerniPostava_JmenoNastaveni_ValidniJmeno()
    {
        HerniPostava postava = new HerniPostava("Hrdina");
        Assert.AreEqual("Hrdina", postava.Jmeno);
    }

    [TestMethod]
    public void HerniPostava_VychoziLevel_Test()
    {
        HerniPostava postava = new HerniPostava("Aragorn");
        Assert.AreEqual(1, postava.Level);
    }

    [TestMethod]
    public void HerniPostava_ZmenaPozice_Test()
    {
        HerniPostava postava = new HerniPostava("Gimli");
        postava.ZmenaPozice();
        Assert.AreEqual(1, postava.PoziceX);
        Assert.AreEqual(1, postava.PoziceY);
    }

    [TestMethod]
    public void HerniPostava_ToString_Test()
    {
        HerniPostava postava = new HerniPostava("Boromir");
        string expected = "Boromir, Level: 1, Pozice: (0, 0)";
        Assert.AreEqual(expected, postava.ToString());
    }
    [TestMethod]
    public void HerniPostava_ToString_VraciSpravnyFormat()
    {
        HerniPostava postava = new HerniPostava("Warrior");
        string expected = "Jméno: Warrior, Level: 1, Pozice: (0, 0)";
        Assert.AreEqual(expected, postava.ToString());
    }
}
