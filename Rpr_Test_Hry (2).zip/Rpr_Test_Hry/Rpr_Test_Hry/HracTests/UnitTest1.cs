﻿using Hra;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Rpr_Test_Hry;
[TestClass]
public class HracTests
{
    [TestMethod]
    public void Hrac_JmenoNastaveni_Test()
    {
        Hrac hrac = new Hrac("Arthas", "Berserker");
        Assert.AreEqual("Arthas", hrac.Jmeno);
    }

    [TestMethod]
    public void Hrac_PrikladXP_Test()
    {
        Hrac hrac = new Hrac("Jaina", "Kouzelník");
        hrac.PridatXP(120);
        Assert.AreEqual(20, hrac.XP);
        Assert.AreEqual(2, hrac.Level);
    }
    [TestMethod]
    public void Hrac_SpecializaceNastaveni_Test()
    {
        Hrac hrac = new Hrac("Thrall", SpecializaceTyp.Inženýr);
        Assert.AreEqual(SpecializaceTyp.Inženýr, hrac.Specializace);
    }
    [TestMethod]
    public void Hrac_XPNepridaPriNule_Test()
    {
        Hrac hrac = new Hrac("Uther", SpecializaceTyp.Kouzelník);
        hrac.PridejXP(0);
        Assert.AreEqual(0, hrac.XP);
        Assert.AreEqual(1, hrac.Level);
    }
    [TestMethod]
    public void Hrac_XPNesmiBytZaporne_Test()
    {
        Hrac hrac = new Hrac("Thrall", SpecializaceTyp.Inženýr);
        hrac.PridejXP(-50);
        Assert.AreEqual(0, hrac.XP);
        Assert.AreEqual(1, hrac.Level);
    }
    [TestMethod]
    public void Hrac_PridejNulaXP_Test()
    {
        Hrac hrac = new Hrac("Anduin", SpecializaceTyp.Kouzelník);
        hrac.PridejXP(0);
        Assert.AreEqual(0, hrac.XP);
        Assert.AreEqual(1, hrac.Level);
    }
    [TestMethod]
    public void Hrac_SpecializaceNastaveni_Test()
    {
        Hrac hrac = new Hrac("Gul'dan", SpecializaceTyp.Kouzelník);
        Assert.AreEqual(SpecializaceTyp.Kouzelník, hrac.Specializace);
    }
    [TestMethod]
    public void Hrac_NastaveniPrilisDlouhehoJmena_Test()
    {
        Hrac hrac = new Hrac("VelmiDlouheJmeno", SpecializaceTyp.Kouzelník);
        Assert.AreNotEqual("VelmiDlouheJmeno", hrac.Jmeno);
    }
}
