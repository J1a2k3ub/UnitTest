﻿using Hra;
using System;

public class Hrac : HerniPostava
{
    private string specializace;
    private static readonly string[] platneSpecializace = { "Kouzelník", "Berserker", "Inženýr", "Cizák" };
    public SpecializaceTyp Specializace { get; private set; }

    public string Specializace
    {
        get { return specializace; }
        set
        {
            if (Array.Exists(platneSpecializace, s => s == value))
            {
                specializace = value;
            }
            else
            {
                Console.WriteLine("Neplatná specializace!");
            }
        }
    }

    public int XP { get; private set; } = 0;

    public Hrac(string jmeno, string specializace) : base(jmeno)
    {
        Specializace = specializace;
    }

    public void PridatXP(int xp)
    {
        
    }

    public override string ToString()
    {
        return base.ToString() + $", Specializace: {Specializace}, XP: {XP}";
    }
}
