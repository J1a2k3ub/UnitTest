﻿using System;

public class NPC : HerniPostava
{
    public string Prace { get; private set; }
    public bool JeBoss { get; private set; }

   


    public NPC(string jmeno, string prace, bool jeBoss) : base(jmeno)
    {
        Prace = prace;
        JeBoss = jeBoss;
    }

    public NPC(string jmeno, string prace) : this(jmeno, prace, false) { }

    public sealed override void ZmenaPozice()
    {
        Console.WriteLine("NPC nemůže měnit pozici.");
    }

    public override string ToString()
    {
        return base.ToString() + $", Práce: {Prace}, Boss: {(JeBoss ? "Ano" : "Ne")}";
    }
}
