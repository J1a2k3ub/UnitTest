﻿using System;

public class HerniPostava
{
    private string jmeno;
    public string Jmeno
    {
        get { return jmeno; }
        set
        {
            if (value.Length > 10)
            {
                Console.WriteLine("Příliš dlouhé jméno!");
            }
            else
            {
                jmeno = value;
            }
        }
    }

    public int Level { get; private set; } = 1;
    public int PoziceX { get; private set; } = 0;
    public int PoziceY { get; private set; } = 0;

    public HerniPostava(string jmeno)
    {
        Jmeno = jmeno;
    }

    public virtual void ZmenaPozice()
    {
        // Simulace změny pozice (v reálné hře by se zde počítala skutečná pozice)
        PoziceX += 1;
        PoziceY += 1;
    }

    public override string ToString()
    {
        return $"{Jmeno}, Level: {Level}, Pozice: ({PoziceX}, {PoziceY})";
    }
}
