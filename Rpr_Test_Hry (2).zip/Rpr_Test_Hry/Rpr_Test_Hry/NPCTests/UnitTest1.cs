﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Rpr_Test_Hry;

[TestClass]
public class NPCTests
{
    [TestMethod]
    public void NPC_Jmeno_Test()
    {
        NPC npc = new NPC("Obchodník", "obchodník");
        Assert.AreEqual("Obchodník", npc.Jmeno);
    }

    [TestMethod]
    public void NPC_ZmenaPozice_Test()
    {
        NPC npc = new NPC("Nepřítel", "nepřítel");
        npc.ZmenaPozice();
        Assert.AreEqual(0, npc.PoziceX);
        Assert.AreEqual(0, npc.PoziceY);
    }
    [TestMethod]
    public void NPC_Konstruktor_BezSily()
    {
        NPC npc = new NPC("Obchodník", PraceTyp.Obchodnik);
        Assert.IsFalse(npc.Sila);
    }
    [TestMethod]
    public void NPC_Konstruktor_SeSilou()
    {
        NPC npc = new NPC("Boss", PraceTyp.Nepritel, true);
        Assert.IsTrue(npc.Sila);
    }
    [TestMethod]
    public void NPC_ToString_Test()
    {
        NPC npc = new NPC("Obchodník", PraceTyp.Obchodnik);
        string expected = "Jméno: Obchodník, Level: 1, Pozice: (0,0), Práce: Obchodník, Sila: False";
        Assert.AreEqual(expected, npc.ToString());
    }
}
